from django.urls import path, include
from todo_app.api.view import NotesListAV, NotesDetailAV

urlpatterns = [
    path('list/', NotesListAV.as_view(), name='note-ist'),
    path('<int:pk>', NotesDetailAV.as_view(), name='note-detail'),
]
