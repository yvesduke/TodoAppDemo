from rest_framework.response import Response
from rest_framework.views import APIView
from todo_app.models import Note
from todo_app.api.serializers import NoteSerializer


class NotesListAV(APIView):
    
    def get(self, request):
        notes = Note.objects.all()
        serializer = NoteSerializer(notes, many=True)
        return Response(serializer.data)
    
    def post(self, request):
         serializer = NoteSerializer(data=request.data)
         if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
         else:
           return Response(serializer.errors, status=400)
       
       
class NotesDetailAV(APIView):
    def get(self, request, pk):   
          try:
             note = Note.objects.get(pk=pk)
             serializer = NoteSerializer(note, data = request.data)
             if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=201)
             return Response(serializer.errors, status=400)
          except Note.DoesNotExist:
            return Response(status=404)    
        
    def put(self, request, pk):
        try:
            note = Note.objects.get(pk=pk)
            serializer = NoteSerializer(note, data = request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=201)
            return Response(serializer.errors, status=400)
        except Note.DoesNotExist:
            return Response(status=404)
        
    def delete(self, request, pk):
        try:
            note = Note.objects.get(pk=pk)
            note.delete()
            return Response(status=204)
        except Note.DoesNotExist:
            return Response(status=404) 
            
