from django.shortcuts import render
from todo_app.models import Note
from django.http  import JsonResponse
# Create your views here.

# def note_list(request):
#     notes = Note.objects.all()
#     data = {
#            'movies': list(notes.values())
#         }
#     return JsonResponse(data)
    