//
//  AddNoteView.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import SwiftUI

struct AddNoteView: View {
    @State var name: String = ""
    @State var desc: String = ""
    @Binding var path: [NavigationTrack]
    @StateObject var viewModel = AddNoteViewModel()
    
    var body: some View {
        showAddNotesView()
        .padding()
        .toolbar {
            ToolbarItem {
                Button(action: saveNotes) {
                    Text("Save")
                }
            }
        }
    }
    
    @ViewBuilder
    func showAddNotesView() -> some View {
        VStack {
            TextField("Name", text: $name)     .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(8)
                .padding(.horizontal)
            ZStack(alignment: .topLeading) {
                TextEditor(text: $desc)
                    .padding()
                    .frame(height:200.0)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(8)
                    .padding(.horizontal)
                if desc.isEmpty {
                    Text("Add Desc")
                        .foregroundColor(.gray)
                        .padding(.leading, 25)
                }
            }
            Spacer()
        }
    }
    private func saveNotes() {
        if !name.isEmpty && !desc.isEmpty {
            withAnimation {
                viewModel.addNote(name: name, desc: desc)
                path.removeLast()
            }
        }
    }
}
