//
//  AddNoteViewModel.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

@MainActor
class AddNoteViewModel: ObservableObject {
    private let networkClient: NetworkClientContract
    private let localCacheManager: LocalCacheManagerContract

    @Published private(set) var viewState: ViewStates = .loading
    private(set) var notes: [Note] = []
    
    init(networkClient: NetworkClientContract = NetworkClient(), localCacheManager: LocalCacheManagerContract = CacheManager()) {
        self.networkClient = networkClient
        self.localCacheManager = localCacheManager
    }
}

extension AddNoteViewModel {
    func addNote(name: String, desc: String) {
        viewState =  .loading
        let noteAddRequest = NoteAddRequest(name:name, desc: desc)
        Task {
            do {
                let _ = try await networkClient.request(noteAddRequest)
                viewState = .loaded
            } catch {
                viewState = .error
            }
        }
    }
}
