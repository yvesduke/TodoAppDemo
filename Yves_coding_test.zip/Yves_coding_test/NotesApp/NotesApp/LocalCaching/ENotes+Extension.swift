//
//  ENotes+Extension.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation
import CoreData

extension ENotes {
    static func saveNotes(_ notes: [Note], moc: NSManagedObjectContext) throws {
        
        notes.forEach { note in
            let eNote = ENotes(context: moc)
            eNote.name = note.name
            eNote.desc = note.description
            eNote.id = Int16(note.id)
            eNote.timestamp = note.timeStamp
        }
   
        try moc.save()
    }
    
    static func fetchNotes(moc: NSManagedObjectContext)-> [ENotes] {
        let fr = ENotes.fetchRequest()
        return (try? moc.fetch(fr)) ?? []
    }
    
    static func deleteNotesRecords(moc: NSManagedObjectContext) throws {
        let items =  ENotes.fetchNotes(moc: moc)
        items.forEach {
            moc.delete($0)
        }
        try moc.save()
    }
    
    func toNote()-> Note {
        return Note(id: Int(id), name: name ?? "", description: desc ?? "", timeStamp: timestamp ?? "")
    }
}
