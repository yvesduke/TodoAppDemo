//
//  LocalCacheManager.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

protocol LocalCacheManagerContract {
    func saveNote(notes: [Note])
    func fetchNotes()-> [Note]
    func deleteNotes()
}

class CacheManager: LocalCacheManagerContract {
    func saveNote(notes: [Note]) {
        deleteNotes()
        try? ENotes.saveNotes(notes, moc: PersistenceController.shared.container.viewContext)
    }
    func fetchNotes()-> [Note] {
       let items =  ENotes.fetchNotes(moc: PersistenceController.shared.container.viewContext)
        
        return items.map { $0.toNote() }
    }
    func deleteNotes() {
        try? ENotes.deleteNotesRecords(moc: PersistenceController.shared.container.viewContext)
    }
}
