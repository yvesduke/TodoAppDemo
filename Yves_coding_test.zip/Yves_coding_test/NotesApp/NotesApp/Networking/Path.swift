//
//  Path.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

struct Path {
    static var path = "todoNotes/list/"
    static var deletePath = "todoNotes/"
}
