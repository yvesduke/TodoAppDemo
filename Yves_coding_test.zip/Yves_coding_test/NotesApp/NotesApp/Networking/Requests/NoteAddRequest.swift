//
//  NoteAddRequest.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

struct NoteAddRequest: RestRequestContract {
    var url: String {
        return RestEndPoints.baseUrl
    }
    var params: [String : String] {
        return ["name": name, "description": desc, "timeStamp": "\(Date.now)"]
    }
    var path: String {
        return Path.path
    }
    var type: RestRequestType {
        return .post
    }
    var name: String
    var desc: String
}
