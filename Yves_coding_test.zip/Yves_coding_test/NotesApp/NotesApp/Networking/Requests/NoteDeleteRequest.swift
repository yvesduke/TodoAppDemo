//
//  NoteDeleteRequest.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

struct NoteDeleteRequest: RestRequestContract {
    var url: String {
        return RestEndPoints.baseUrl
    }
    var params: [String : String] {
        return [:]
    }
    var path: String {
        return Path.deletePath.appending("\(noteId)")
    }
    var type: RestRequestType {
        return .delete
    }
    var noteId: Int
}
