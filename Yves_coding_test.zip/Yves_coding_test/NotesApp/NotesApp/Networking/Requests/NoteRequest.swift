//
//  NoteRequest.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

struct NoteRequest: RestRequestContract {    
    var url: String {
        return RestEndPoints.baseUrl
    }
    var params: [String : String] {
        return [:]
    }
    var path: String {
        return Path.path
    }
    var type: RestRequestType {
        return .get
    }
}
