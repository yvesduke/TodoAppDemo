//
//  RestEndPoints.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

struct RestEndPoints {
    static var baseUrl = "http://127.0.0.1:8000/"
}
