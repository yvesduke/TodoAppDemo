//
//  RestRequest.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

enum RestRequestType: String {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case delete = "DELETE"
}

protocol RestRequestContract {
    var url: String {get}
    var path: String {get}
    var params: [String: String] {get}
    var type: RestRequestType {get}
}
