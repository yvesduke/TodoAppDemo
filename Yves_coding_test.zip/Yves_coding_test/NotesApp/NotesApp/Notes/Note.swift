//
//  Note.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import Foundation

struct Note: Decodable {
    let id: Int
    let name: String
    let description: String
    let timeStamp: String
}

extension Note: Identifiable {}
