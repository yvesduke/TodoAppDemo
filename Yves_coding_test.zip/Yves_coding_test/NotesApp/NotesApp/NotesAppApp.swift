//
//  NotesAppApp.swift
//  NotesApp
//
//  Created by Yves on 22/05/23.
//

import SwiftUI

@main
struct NotesAppApp: App {
    var body: some Scene {
        WindowGroup {
            NotesView(viewModel: NotesViewModel())
        }
    }
}
